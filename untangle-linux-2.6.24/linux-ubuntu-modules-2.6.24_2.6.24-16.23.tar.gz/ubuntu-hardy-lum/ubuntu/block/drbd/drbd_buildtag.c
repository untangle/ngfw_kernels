/* automatically generated. DO NOT EDIT. */
const char * drbd_buildtag(void)
{
	return "GIT-hash: b3fe2bdfd3b9f7c2f923186883eb9e2a0d3a5b1b"
		" build by phil@mescal, 2008-02-12 11:56:43";
}
