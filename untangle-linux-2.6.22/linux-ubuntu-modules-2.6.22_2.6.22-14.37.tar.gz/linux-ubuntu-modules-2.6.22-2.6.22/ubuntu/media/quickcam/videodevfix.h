#ifndef VIDEODEVFIX_H
#define VIDEODEVFIX_H

#include <sys/types.h>

typedef int8_t    __s8;
typedef u_int8_t  __u8;
typedef int16_t   __s16;
typedef u_int16_t __u16;
typedef int32_t   __s32;
typedef u_int32_t __u32;
typedef int64_t   __s64;
typedef u_int64_t __u64;

#endif
