/*
 * mac80211 configuration hooks for cfg80211
 */
#ifndef __IEEE80211_CFG_H
#define __IEEE80211_CFG_H

extern struct cfg80211_ops mac80211_config_ops;

#endif /* __IEEE80211_CFG_H */
