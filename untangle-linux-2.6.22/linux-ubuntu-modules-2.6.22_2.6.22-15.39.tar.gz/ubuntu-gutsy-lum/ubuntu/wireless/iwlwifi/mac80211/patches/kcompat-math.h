#ifndef __kcompat_math_h__
#define __kcompat_math_h__

#ifndef DIV_ROUND_UP
#define DIV_ROUND_UP(n,d) (((n) + (d) - 1) / (d))
#endif

#endif
